﻿using System;
using System.Collections.Generic;


namespace Proj3
{
    class Program
    {
        /*Задание: С клавиатуры вводятся числа, пока не будет введен 0. Подсчитать сумму всех нечетных положительных чисел.
         Фамилия: Орлов
         */
        static public int num;
        static void Main(string[] args)
        {
            Console.Title = "Подсчёт суммы всех нечетных положительных чисел";
            Work();
        }
        static public void Work()
        {
            List<int> list = new List<int>();
            do
            {
                Console.Clear();
                Console.WriteLine("Для выхода из цикла введите 0");
                num = Proj2.Program.GetAndCheckINT();
                if (num % 2 == 0 && num > 0) // проверяю на чётность введённое число
                    list.Add(num);

            }
            while (num != 0);
            PrintSum(list);
        }
        static public void PrintSum(List<int> list)
        {
            Console.Clear();

            int sum = 0;
            Console.WriteLine("Введённые положительные чётные числа: ");
            foreach (int i in list)
            {
                sum += i;
                Console.Write($"{i};");
            }
            Console.WriteLine();
            Console.WriteLine($"Сумма чисел: {sum}");
            Console.ReadKey(true);
        }
    }
}
