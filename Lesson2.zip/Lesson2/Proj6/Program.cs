﻿using System;


namespace Proj6
{
    /*Задание: Написать программу подсчета количества «Хороших» чисел в диапазоне от 1 до 1 000 000 000. 
     * Хорошим называется число, которое делится на сумму своих цифр.
     * Реализовать подсчет времени выполнения программы, используя структуру DateTime.
     Фамилия: Орлов
     */
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Подсчёт кол-ва 'хороших' чисел";
            Work();
        }
        static public void Work()
        {
            DateTime start = DateTime.Now;            
            int countgoodnum = 0;
            for (int i = 1; i <= 1000000000; i++)
                if (i % RecursiveSum(i) == 0) // если я правильно понял условие, что число делится на сумму своих цифр без остатка
                    countgoodnum++;
            Console.WriteLine($"«Хороших» чисел в диапазоне от 1 до 1 000 000 000: {countgoodnum}");
            DateTime finish = DateTime.Now;
            Console.WriteLine(finish - start);
            Console.ReadKey(true);
        }
        public static int RecursiveSum(int a)
        {
            if (a == 0)
                return 0;
            else return RecursiveSum(a / 10) + a % 10;
        }
    }
}
