﻿using System;
using System.Collections.Generic;


namespace Proj1
{
    /*Задание: Написать метод, возвращающий минимальное из трех чисел.
     Фамилия: Орлов
     */
    public class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Вывод минимального из 3-х чисел";
            Work();
        }
        public static void Work()
        {
            int maxcount = 3; // кол-во чисел
            List<int> list = new List<int>();
            for (int i = 1; i <= maxcount; i++)
                list.Add(GetAndCheckINT(i));
            PrintMinValue(list);
        }
        public static int GetAndCheckINT(int n)
        {
            int num = 0;
            while (true)
            {
                Console.Write($"Введите {n} число: ");
                if (Int32.TryParse(Console.ReadLine(), out num))
                    break;
                else
                {
                    Console.Clear();
                    Console.WriteLine($"Введённое значение не число!, попробуйте снова");
                }
            }
            return num;
        }
        public static void PrintMinValue(List<int> list)
        {
            Console.Clear();
            int min = list[0];
            foreach (int i in list)
                if (i < min)
                    min = i;
            Console.Write($"Введённые числа: ");
            foreach (int i in list)
                Console.Write($"{i};");
            Console.WriteLine();
            Console.WriteLine($"Минимальное число: {min}");
            Console.ReadKey(true);
        }
    }
}
