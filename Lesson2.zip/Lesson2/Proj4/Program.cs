﻿using System;


namespace Proj4
{
    /*Задание: Реализовать метод проверки логина и пароля. На вход подается логин и пароль. 
     * На выходе истина, если прошел авторизацию, и ложь, если не прошел (Логин: root, Password: GeekBrains). 
     * Используя метод проверки логина и пароля, написать программу: пользователь вводит логин и пароль,
     * программа пропускает его дальше или не пропускает. С помощью цикла do while ограничить ввод пароля тремя попытками.
     Фамилия: Орлов
     */
    class Program
    {
        static public int attempt = 3;

        static void Main(string[] args)
        {
            Console.Title = "Авторизация";
            Authorization();

        }
        static public void Authorization()
        {
            string password = "GeekBrains";
            string login = "root";

            do
            {
                Console.Clear();
                Console.Write("Введите пароль: ");
                string temppassw = Console.ReadLine();
                Console.Write("Введите логин: ");
                string templogin = Console.ReadLine();

                if (templogin != login || temppassw != password)
                {
                    Console.WriteLine($"Вы ввели неверные данные\nУ вас осталось {--attempt} попыток(Для продолжения нажмите любую кнопку)");
                    Console.ReadKey(true);
                }
                else
                {
                    Console.WriteLine($"Вы ввели верные данные!");
                    Console.ReadKey(true);
                    break;
                }
            }
            while (attempt > 0);
        }
    }
}
