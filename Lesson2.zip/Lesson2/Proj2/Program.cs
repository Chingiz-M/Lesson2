﻿using System;


namespace Proj2
{
    /*Задание: Написать метод подсчета количества цифр числа.
     Фамилия: Орлов
     */
    public class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Вывод кол-ва цифр в числе";
            Work();
        }
        public static void Work()
        {
            int num = GetAndCheckINT();
            Console.Clear();
            Console.WriteLine($"Введённое число: {num}\nКол-во цифр в числе: {RecursiveSum(num)}");
            Console.ReadKey(true);
        }
        public static int RecursiveSum(int a)
        {
            if (a == 0)
                return 0;
            else return RecursiveSum(a / 10) + 1;   
        }
        public static int GetAndCheckINT()
        {
            int num = 0;
            while (true)
            {
                Console.Write($"Введите число: ");
                if (Int32.TryParse(Console.ReadLine(), out num))
                    break;
                else
                {
                    Console.Clear();
                    Console.WriteLine($"Введённое значение не число!, попробуйте снова");
                }
            }
            return num;
        }
    }
}
