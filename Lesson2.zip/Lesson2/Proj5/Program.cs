﻿using System;


namespace Proj5
{
    /*Задание: а) Написать программу, которая запрашивает массу и рост человека, вычисляет его индекс массы и сообщает, 
                  нужно ли человеку похудеть, набрать вес или все в норме;
               б) Рассчитать, на сколько кг похудеть или сколько кг набрать для нормализации веса.
     Фамилия: Орлов
     */
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Расчёт индекса массы тела (ИМТ)";
            Work(); 
            
        }
        static public void Work()
        {
            string sex = CheckSex("Ваш пол (Введите:\"М\" или \"Ж\"): ").ToLower();
            double weight = CheckDouble("Ваш вес(кг): ");
            double height = CheckDouble("Ваш рост(м): ");
            Print(weight, height, sex, GetIMT(weight, height));
        }
        public static void Print(double weight, double height, string sex, double IMT)
        {
            Console.WriteLine($"Ваш вес(кг): {weight}");
            Console.WriteLine($"Ваш рост(м): {height}");
            Console.WriteLine("ИМТ = {0:0.00}", IMT);
            if(sex == "м") // если мужчины
            {
                if (IMT < 23)
                    Console.WriteLine("Вам необходимо набрать {0:0.00} кг!" +
                        $" Нормальный ИМТ для мужчины от 23 до 25", GetMinMenWeight(height) - weight);
                if (IMT > 25)
                    Console.WriteLine("Вам необходимо сбросить {0:0.00} кг!" +
                        $" Нормальный ИМТ для мужчины от 23 до 25", weight - GetMaxMenWeight(height));
                if (IMT < 25 && IMT > 23)
                    Console.WriteLine("Нормальный ИМТ для мужчины от 23 до 25");
            }
            else
            {
                if (IMT < 20)
                    Console.WriteLine("Вам необходимо набрать {0:0.00} кг!" +
                        $" Нормальный ИМТ для женщин от 20 до 22", GetMinWomenWeight(height) - weight);
                if (IMT > 22)
                    Console.WriteLine("Вам необходимо сбросить {0:0.00} кг!" +
                        $" Нормальный ИМТ для женщин от 20 до 22", weight - GetMaxWomenWeight(height));
                if (IMT < 22 && IMT > 20)
                    Console.WriteLine("Нормальный ИМТ для женщин от 23 до 25");
            }
            Console.ReadKey(true);
        }
        public static string GetValue(string value)
        {
            Console.Write(value);
            string result = Console.ReadLine();
            Console.WriteLine();
            return result;
        }
        public static double CheckDouble(string value)
        {
            double num = 0;
            while (true)
            {
                if (Double.TryParse(GetValue(value), out num))
                {
                    Console.Clear();
                    break;
                }
                else
                {
                    Console.Clear();
                    Console.WriteLine("Введённое значение не число!, попробуйте снова");
                }
            }
            return num;
        }
        public static string CheckSex(string value)
        {
            string result = null;
            while (true)
            {
                Console.Clear();
                result = GetValue(value).ToLower();

                if (result == "м" || result == "ж")
                    break;
                else
                    Console.WriteLine("Введите:\"М\" или \"Ж\"");
            }
            return result;
        }
        public static double GetIMT(double weight, double height) => weight / (height * height);
        public static double GetMaxMenWeight(double height) => 25 * (height * height);
        public static double GetMinMenWeight(double height) => 23 * (height * height);
        public static double GetMaxWomenWeight(double height) => 22 * (height * height);
        public static double GetMinWomenWeight(double height) => 20 * (height * height);

    }
}
