﻿using System;
using System.Collections.Generic;

namespace Proj7
{
    /*Задание: a) Разработать рекурсивный метод, который выводит на экран числа от a до b (a<b);
               б) Разработать рекурсивный метод, который считает сумму чисел от a до b.
     Фамилия: Орлов
     */
    class Program
    {
        static void Main(string[] args)
        {
            Console.Title = "Рекурсивный метод";
            Work();
        }
        static public void Work()
        {
            int start = Proj1.Program.GetAndCheckINT(1);
            int finish;
            while (true)
            {
                Console.Clear();
                finish = Proj1.Program.GetAndCheckINT(2);
                if (finish < start)
                {
                    Console.WriteLine("Введите число больше первого");
                    Console.ReadKey(true);
                }
                else
                    break;
            }
            Console.Clear();
            Console.Write($"Числа от {start} до {finish}: ");

            Console.WriteLine($"Сумма чисел = {GetRecursiveSum(start, finish)}");
            Console.ReadKey(true);
        }
        public static int GetRecursiveSum(int start, int finish)
        {
            if (start == finish)
            {
                Console.Write($"{finish}; ");
                Console.WriteLine();
                return start;
            }
            else
            {
                Console.Write($"{finish}; ");
                int res = finish;
                return GetRecursiveSum(start, finish - 1) + res;
            }
        }
    }
}
